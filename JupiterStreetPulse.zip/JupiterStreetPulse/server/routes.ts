import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { eq, and, desc, like } from "drizzle-orm";
import { videos, tags, progressMetrics, productionTimeline, qrCodes, animatedOutros } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix
  const apiPrefix = '/api';
  
  // GET short-form videos
  app.get(`${apiPrefix}/videos/short-form`, async (req, res) => {
    try {
      const location = req.query.location as string | undefined;
      
      let shortVideos;
      if (location) {
        shortVideos = await storage.getVideosByTypeAndLocation('short-form', location);
      } else {
        shortVideos = await storage.getVideosByType('short-form');
      }
      
      res.json(shortVideos);
    } catch (error) {
      console.error('Error fetching short-form videos:', error);
      res.status(500).json({ error: 'Failed to fetch short-form videos' });
    }
  });
  
  // GET long-form video
  app.get(`${apiPrefix}/videos/long-form`, async (req, res) => {
    try {
      const longFormVideo = await storage.getLongFormVideo();
      res.json(longFormVideo);
    } catch (error) {
      console.error('Error fetching long-form video:', error);
      res.status(500).json({ error: 'Failed to fetch long-form video' });
    }
  });
  
  // GET featured video
  app.get(`${apiPrefix}/videos/featured`, async (req, res) => {
    try {
      const featuredVideo = await storage.getFeaturedVideo();
      res.json(featuredVideo);
    } catch (error) {
      console.error('Error fetching featured video:', error);
      res.status(500).json({ error: 'Failed to fetch featured video' });
    }
  });
  
  // GET video by ID
  app.get(`${apiPrefix}/videos/detail/:id`, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      if (isNaN(videoId)) {
        return res.status(400).json({ error: 'Invalid video ID' });
      }
      
      const video = await storage.getVideoById(videoId);
      if (!video) {
        return res.status(404).json({ error: 'Video not found' });
      }
      
      res.json(video);
    } catch (error) {
      console.error('Error fetching video details:', error);
      res.status(500).json({ error: 'Failed to fetch video details' });
    }
  });
  
  // POST increment video view count
  app.post(`${apiPrefix}/videos/:id/view`, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      if (isNaN(videoId)) {
        return res.status(400).json({ error: 'Invalid video ID' });
      }
      
      await storage.incrementVideoViews(videoId);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Error updating view count:', error);
      res.status(500).json({ error: 'Failed to update view count' });
    }
  });
  
  // GET long-form video stats
  app.get(`${apiPrefix}/videos/long-form/stats`, async (req, res) => {
    try {
      const stats = await storage.getLongFormStats();
      res.json(stats);
    } catch (error) {
      console.error('Error fetching long-form stats:', error);
      res.status(500).json({ error: 'Failed to fetch long-form stats' });
    }
  });
  
  // GET progress metrics
  app.get(`${apiPrefix}/progress`, async (req, res) => {
    try {
      const metrics = await storage.getProgressMetrics();
      res.json({ metrics });
    } catch (error) {
      console.error('Error fetching progress metrics:', error);
      res.status(500).json({ error: 'Failed to fetch progress metrics' });
    }
  });
  
  // GET production timeline
  app.get(`${apiPrefix}/progress/timeline`, async (req, res) => {
    try {
      const timeline = await storage.getProductionTimeline();
      res.json(timeline);
    } catch (error) {
      console.error('Error fetching production timeline:', error);
      res.status(500).json({ error: 'Failed to fetch production timeline' });
    }
  });
  
  // GET QR code data
  app.get(`${apiPrefix}/qr-code`, async (req, res) => {
    try {
      const qrCode = await storage.getQrCode();
      res.json(qrCode);
    } catch (error) {
      console.error('Error fetching QR code:', error);
      res.status(500).json({ error: 'Failed to fetch QR code' });
    }
  });
  
  // GET animated outro
  app.get(`${apiPrefix}/outro`, async (req, res) => {
    try {
      const outro = await storage.getAnimatedOutro();
      res.json(outro);
    } catch (error) {
      console.error('Error fetching animated outro:', error);
      res.status(500).json({ error: 'Failed to fetch animated outro' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
